$(function() {

var $list = $('li');
$list.filter(':lt(2)').css({
    'color': '#000',
    'text-shadow': '2px 2px 8px #FF0000',
});

$list.filter(':first').addClass('firstItem');
$list.filter(':not(.firstItem)').addClass('Item');
$list.filter('.Item:last').prepend('Last item: ');
$list.filter(':lt(2)').prepend('Important: ');

$list.filter(':gt(1)').on('mouseover', function(){
  $(this).children('span').remove();
  $(this).append(' <span class="unimportant">' + "-- Unimportant" + '</span>')
} );


$list.on('mouseout', function(){
  $(this).children('span').remove();
});

});
