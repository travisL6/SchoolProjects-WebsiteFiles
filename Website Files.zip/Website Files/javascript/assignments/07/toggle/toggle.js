$(function() {

var $h2 = $('h2');
$('ul').hide();
$h2.append('<a class="show"> show</a>');
$h2.append('<a class="hide"> hide</a>');
$h2.find('a.hide').hide();

$h2.css( {
    'color': '#000',
  'font-size': '24px',
  'font-weight': 'normal',
  'text-align': 'center',
  'text-transform': 'uppercase',
  'letter-spacing': '.2em',
  'display': 'inline-block',
})

$h2.find('a.show').on('click', function() {
    $h2.find('a.show').toggle();
    $h2.find('a.hide').toggle();
    $h2.next('ul')
      .fadeIn(500);
});

$h2.find('a.hide').on('click', function()
{
  $h2.find('a.show').toggle();
  $h2.find('a.hide').toggle();
  $h2.next('ul')
      .fadeOut(350);
})
});
