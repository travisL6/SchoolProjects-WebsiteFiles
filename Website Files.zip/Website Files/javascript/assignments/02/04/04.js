var NFC = ["Packers", "Bears", "Lions", "Vikings"];

var Packers = NFC[0];

alert(Packers);
