var porsche = "Robert's Porsche is blue";

alert(porsche);
alert("Robert's height is 6'2''");
