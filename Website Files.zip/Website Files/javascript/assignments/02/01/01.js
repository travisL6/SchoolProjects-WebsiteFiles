// This is a single line comment

/*
This is a multi-line comment.
This is a multi-line comment.
*/
