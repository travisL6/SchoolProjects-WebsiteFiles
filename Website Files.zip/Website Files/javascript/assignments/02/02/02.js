var a = 6;
var b = "boy";
var c = true;

alert(a);
alert(b);
alert(c);
