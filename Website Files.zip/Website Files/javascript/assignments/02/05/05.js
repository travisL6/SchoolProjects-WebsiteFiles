var message = "Hello";

var world = "World";

alert(message + " " + world);
