var msg = '';
var truth = true;
var truthy = true;
if (truth === truthy) {
  msg = 'this is a truthy';
} else {
  msg = 'this is a falsy';
}
var el = document.getElementById('answer');
el.textContent = msg;
