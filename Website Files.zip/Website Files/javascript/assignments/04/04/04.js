var msg;
var c = 50;


switch (c) {
case 30:
    msg = 'You failed';
    break;

case 40:
    msg = 'You did okay';
    break;

case 50:
    msg = 'You did perfect!';
    break;

default:
    msg = 'Good luck and have fun!';
    break;
}

var el = document.getElementById('score');
el.textContent = msg;
