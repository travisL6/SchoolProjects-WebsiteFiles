var x = 50;
var msg = '';

function congratulate() {
  msg += 'Congratulations! ';
}

if (x >= 50) {
  congratulate();
}

var el = document.getElementById('number');
el.textContent = msg;
