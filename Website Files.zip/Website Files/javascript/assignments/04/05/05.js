var colors = ['green', 'yellow', 'blue', 'red', 'orange', 'white', 'black', 'purple', 'gray', 'pink'];
var index;
var color;
var msg = '';

for (var i = 0; i < colors.length; i++) {
  index = (i + 1);
  msg += 'Color ' + index + ' is ' + colors[i] + ',' + ' ';
}
var el = document.getElementById('color');
el.textContent = msg;
