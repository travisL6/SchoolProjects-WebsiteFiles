var x = 10;
var msg = '';
if (x > 9 || x < 20) {
  msg = 'short circuit complete';
} else {
  msg = 'short circuit failed';
}
var el = document.getElementById('circuit');
el.textContent = msg;
