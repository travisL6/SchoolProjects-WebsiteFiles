var msg = '';
if (document.getElementById('truthy')) {
  msg = 'this is a truthy';
} else {
  msg = 'this is a falsy';
}
var el = document.getElementById('answer')
el.textContent = msg;
