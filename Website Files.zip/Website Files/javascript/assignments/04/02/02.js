var a = "apple";
var c = 6;

var comparison = a == c;

var el = document.getElementById('comparison');
el.textContent = 'Comparison is ' + comparison;
