var x = 3;
var msg;

if (x > 2) {
    msg = 'x is greater than 2'
} else {
    msg = "x is not greater than 2"
}

var el = document.getElementById('msg');
el.textContent = msg;
