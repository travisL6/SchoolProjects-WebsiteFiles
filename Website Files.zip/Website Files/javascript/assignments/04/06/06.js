var num = 2;
var i = 1;
var msg = '';

if (num == 2) {
  while(i < 10) {
    msg += 'index ' + i + ' is ' + (i + num) + ', ';
    i++;
  }
} else {
  while(i < 10) {
    msg += 'index: ' + i + ' ' + (num - i);
    i++;
  }
}
var el = document.getElementById('num');
el.textContent = msg;
