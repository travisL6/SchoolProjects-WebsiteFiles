$(function() {
var elDocument = document.documentElement;
elDocument.className = elDocument.className.replace(/(^|\s)no-js(\s|$)/, '$1');

  if (typeof jQuery != 'undefined') {
    //If jQuery is loaded, display my name and the version of jQuery.
      console.group("Name and Version:");
        console.log("Travis Lambert's Final")
        console.log("JQUERY VERSION: " + jQuery.fn.jquery);
  }
  (function($) {
  $.fn.tabs = function(){
    $('.tab-list').each(function(){
    var $this = $(this);                 // Store this list
    var $tab = $this.find('li.active');             // Get the active list item
    var $link = $tab.find('a');                     // Get link from active tab
    var $panel = $($link.attr('href'));             // Get active panel

    $this.on('click', '.tab-control', function(e) { // When click on a tab
      e.preventDefault();                           // Prevent link behavior
      var $link = $(this),                          // Store the current link
          id = this.hash;                           // Get href of clicked tab

      if (id && !$link.parent().is('.active')) {    // If not currently active
        $panel.removeClass('active');               // Make panel inactive
        $tab.removeClass('active');                 // Make tab inactive

        $panel = $(id).addClass('active');          // Make new panel active
        $tab = $link.parent().addClass('active');   // Make new tab active
      }
    });
    return this;
  });
}
} (jQuery));

$('.tab-list').tabs();
});
