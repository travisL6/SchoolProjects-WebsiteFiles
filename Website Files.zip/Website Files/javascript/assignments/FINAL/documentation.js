$(function() {
var elDocument = document.documentElement;
elDocument.className = elDocument.className.replace(/(^|\s)no-js(\s|$)/, '$1');

  if (typeof jQuery != 'undefined') {
    //If jQuery is loaded, display my name and the version of jQuery.
      console.group("Name and Version:");
        console.log("Travis Lambert's Final")
        console.log("JQUERY VERSION: " + jQuery.fn.jquery);
  }
});
