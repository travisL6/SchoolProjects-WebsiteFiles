$(function() {
  var elDocument = document.documentElement;
elDocument.className = elDocument.className.replace(/(^|\s)no-js(\s|$)/, '$1');

if (typeof jQuery != 'undefined') {
  //If jQuery is loaded, display my name and the version of jQuery.
    console.group("Name and Version:");
      console.log("Travis Lambert's Final")
      console.log("JQUERY VERSION: " + jQuery.fn.jquery);
}

  $("form").validate({
    errorPlacement: function(error, element) {
      error.prependTo(element.parent());
    },
    success: function(label) {
      label.parent().removeClass("error-parent");
    },
    highlight: function(element, errorClass) {
                    $(element).parent().addClass("error-parent");
                    $(element).parent().find(".error").fadeOut(function() {
                        $(this).fadeIn();
                    });
    },
    rules: {
                    name: {
                      required: true
                    },

                    email: {
                        required: true,
                        email: true
                    },

                    username: {
                        required: true,
                        minlength: 5
                    },

                    password: {
                        required: true,
                        minlength: 8
                    },

                    nfcdivisions: {
                        required: true,
                    },

                    afcdivisions: {
                        required: true
                    },

                    radio: {
                      required: true
                    },

                    radio2: {
                      required: true
                    },

                    check: {
                      required: true,
                      minlength: 2
                    },

                    textarea: {
                      required: true,
                      minlength: 4
                    }

                },
                messages: {
                    name: {
                      required: "Please enter your name"
                    },
                    email: {
                      required: "Please enter an email",
                      email: "You must enter a valid email"
                    },
                    username: {
                        required: "Please enter a username",
                        minlength: "Your username must consist of at least 5 characters"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 8 characters long"
                    },
                    nfcdivisions: {
                        required: "Please select a division."
                    },
                    afcdivisions: {
                        required: "Please select a division.",
                    },
                    radio: {
                      required: "Please choose one"
                    },
                    radio2: {
                      required: "Please choose one"
                    },
                    check: {
                      required: "Please select 2 options",
                      minlength: "You need to select at least 2 options"
                    },
                    textarea: {
                        required: "Please enter a comment",
                        minlength: "Your comment must consist of at least 4 characters"
                    }
                }
              });

});
