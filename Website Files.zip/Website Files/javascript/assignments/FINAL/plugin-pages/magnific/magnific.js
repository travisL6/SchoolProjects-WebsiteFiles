$(function() {
  var elDocument = document.documentElement;
  elDocument.className = elDocument.className.replace(/(^|\s)no-js(\s|$)/, '$1');

  if (typeof jQuery != 'undefined') {
    //If jQuery is loaded, display my name and the version of jQuery.
      console.group("Name and Version:");
        console.log("Travis Lambert's Final")
        console.log("JQUERY VERSION: " + jQuery.fn.jquery);
  }

  $('#popup').magnificPopup({
    items: [
      {
        src: 'images/cat.jpg',
        title: 'Bread cat'
      },
      {
      src: 'images/corgi.jpg',
      title: "Cute corgi"
      },
      {
        src: 'images/hamster.jpg',
        title: 'A little hamster'
      },
    ],
    gallery: {
      enabled: true
    },
    type: 'image'
  });
});
