$(function() {
var elDocument = document.documentElement;
elDocument.className = elDocument.className.replace(/(^|\s)no-js(\s|$)/, '$1');

  if (typeof jQuery != 'undefined') {
    //If jQuery is loaded, display my name and the version of jQuery.
      console.group("Name and Version:");
        console.log("Travis Lambert's Final")
        console.log("JQUERY VERSION: " + jQuery.fn.jquery);
  }

$('#confirm').click(function(){
  alertify.set({ labels: {
    ok     : "Confirm Delete",
    cancel : "Cancel"
  }
});
    // confirm dialog
    alertify.confirm("Are you sure you want to delete this?", function (e) {
        if (e) {
          // alert dialog
          alertify.confirm("This can not be reversed, are you still sure?", function (event) {
            if (event) {
              alertify.success("Successfully deleted");
            }
            else
            {
              alertify.error("Deletion cancelled");
            }
          });
        } else {
            alertify.error("Deletion process cancelled");
        }
    });
});

});
