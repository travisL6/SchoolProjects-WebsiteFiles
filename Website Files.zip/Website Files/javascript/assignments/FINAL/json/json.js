$(function() {
var elDocument = document.documentElement;
elDocument.className = elDocument.className.replace(/(^|\s)no-js(\s|$)/, '$1');

  if (typeof jQuery != 'undefined') {
    //If jQuery is loaded, display my name and the version of jQuery.
      console.group("Name and Version:");
        console.log("Travis Lambert's Final")
        console.log("JQUERY VERSION: " + jQuery.fn.jquery);
  }

  var xhr = new XMLHttpRequest();

  xhr.onload = function() {

    responseObject = JSON.parse(xhr.responseText);

    var newContent = '';
    for (var i = 0; i < responseObject.events.length; i++) {
      newContent += '<div class="event">';
      newContent += '<img src="' + responseObject.events[i].image +'" height= "300" width="300"/>';
      newContent += '<p><b>' + responseObject.events[i].info + '</b></p>';
      newContent += '</div>';
    }
    document.getElementById('content').innerHTML = newContent;

  }

xhr.open('GET', 'json-data.json', true);
xhr.send(null);
});
