var elForm, elSelectTeam, elTeamHint, elTerms, elTermsHint; // Declare variables
elForm          = document.getElementById('formSignup');          // Store elements
elSelectTeam = document.getElementById('team');
elTeamHint   = document.getElementById('teamHint');
elTerms         = document.getElementById('terms');
elTermsHint     = document.getElementById('termsHint');

function teamHint() {                                 // Declare function
  var team = this.options[this.selectedIndex].value;     // Get selected option
  if (team !== 'packers') {                              // If monthly package
    elTeamHint.innerHTML = 'Too bad!';//Show this msg
  } else {                                               // Otherwise
    elTeamHint.innerHTML = 'Now that is what I am talking about';            // Show this message
  }
}

function checkTerms(event) {                             // Declare function
  if (!elTerms.checked) {                                // If checkbox ticked
    elTermsHint.innerHTML = 'You must agree to the terms.'; // Show message
    event.preventDefault();                              // Don't submit form
  }
}

//Create event listeners: submit calls checkTerms(), change calls packageHint()
elForm.addEventListener('submit', checkTerms, false);
elSelectTeam.addEventListener('change', teamHint, false);
