function createImage() {
  var el = document.getElementById('image');
  var h2 = document.getElementById('header');
  var newPEl = document.createElement('p');
  var newImageEl = document.createElement('img');
  var src = el.getAttribute('href');
    newImageEl.setAttribute('src', src);
    h2.parentNode.insertBefore(newPEl, h2.nextSibling);
    newPEl.appendChild(newImageEl);
    return false;
}
var a = document.getElementById('image');
a.onclick = createImage;
