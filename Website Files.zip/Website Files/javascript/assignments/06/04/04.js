var elUsername = document.getElementById('username');
var elPassword = document.getElementById('password');

elUsername.addEventListener("blur", checkUsername, false);
elPassword.addEventListener("blur", checkPassword, false);
function checkUsername() {                            // Declare function
  var elUserMsg = document.getElementById('Ufeedback');    // Get feedback element
  if (this.value.length < 5) {                        // If username too short
    elUserMsg.textContent = 'Username must be 5 characters or more';  // Set msg
  } else {                                            // Otherwise
    elUserMsg.textContent = '';                           // Clear message
  }
}

function checkPassword() {
var elPassMsg = document.getElementById('Pfeedback');
if (this.value.length < 10) {
  elPassMsg.textContent = "Password must be 10 characters or more";
} else {
  elPassMsg.textContent = '';
  }
}
