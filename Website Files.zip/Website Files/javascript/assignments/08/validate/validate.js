$(function() {
            $("#form").validate({
                errorPlacement: function(error, element) {
                    error.appendTo(element.parent());
                    if (element.attr("name") == "comment"
                        || element.attr("name") == "teams"
                        || element.attr("name") == "pet[]"
                        || element.attr("name") == "sport") {
                        error.prependTo(element.parent());
                    }
                },
                success: function(label) {
                    label.parent().removeClass("error-parent");
                },
                highlight: function(element, errorClass) {
                    $(element).parent().addClass("error-parent");
                    $(element).parent().find(".error").fadeOut(function() {
                        $(this).fadeIn();
                    });
                },
                rules: {
                    username: {
                        required: true,
                        minlength: 3
                    },
                    password: {
                        required: true,
                        minlength: 6
                    },
                    teams: {
                        required: true
                    },
                    'pet[]': {
                        required: true,
                        minlength: 4
                    },
                    sport: {
                        required: true
                    },
                    comment: {
                      required: true,
                      minlength: 4
                    }

                },
                messages: {
                    username: {
                        required: "Please enter a username",
                        minlength: "Your username must consist of at least 3 characters"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 6 characters long"
                    },
                    sport: {
                        required: "Please select your sport."
                    },
                    'pet[]': {
                        required: "Please choose at least 4 pets.",
                        minlength: "You must choose at least 4 pets."
                    },
                    comment: {
                        required: "Please enter a comment",
                        minlength: "Your comment must consist of at least 4 characters"
                    }
                }
            });


        });
