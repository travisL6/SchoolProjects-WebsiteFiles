var xhr = new XMLHttpRequest();

xhr.onload = function() {

    responseObject = JSON.parse(xhr.responseText);

    var newContent = '';
    for (var i = 0; i < responseObject.events.length; i++) {
      newContent += '<div class="event">';
      newContent += '<img src="' + responseObject.events[i].animal +'" height= "300" width="300"/>';
      newContent += '<p><b>' + responseObject.events[i].type + '</b></p>';
      newContent += '</div>';
    }
    document.getElementById('content').innerHTML = newContent;

  }

xhr.open('GET', 'json-data.json', true);
xhr.send(null);
