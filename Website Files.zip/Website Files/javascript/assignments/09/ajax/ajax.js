var xhr = new XMLHttpRequest();

xhr.onload = function() {
  document.getElementById('content').innerHTML = xhr.responseText;
}
xhr.open('GET', 'ajax-data.html', true);
xhr.send(null);
