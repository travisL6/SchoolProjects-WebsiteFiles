window.onload = function() {

var divPage = document.getElementById('page');
var elP = document.getElementsByTagName('p');
var newElUl = document.createElement('ul');
divPage.insertBefore(newElUl, elP[0]);

	// Loop through element p node list and create li elements using their text content.
	for (var i = 0; i < elP.length; i++) {
		var newElLi = document.createElement('li');
		newElLi.textContent = elP[i].textContent;
		newElUl.appendChild(newElLi);
	}


var firstItem = newElUl.firstChild;
var lastItem = newElUl.lastChild;
var elLi = document.getElementsByTagName('li');
var num = 0;

	// Loop through element li node list that was created in previous for loop
	for (var x = 0; x < elLi.length; x++) {
		// If statement to determine if it is first or last item of the list
		if(elLi[x] == firstItem || elLi[x] == lastItem) {
			elLi[x].setAttribute('class', 'complete');
		}
		else {
			elLi[x].setAttribute('class', 'cool');
			num++;
		}
		divPage.removeChild(elP[0]);
	}
var elH2 = document.getElementsByTagName('h2')[0];
var msg = ': ' + num + ' - Items Remaining';
elH2.textContent += msg;

var elTitle = document.getElementsByTagName('title')[0];
var msg2 = num + ' - Items Remaining' + ' | ' + elTitle.textContent;

elTitle.textContent = msg2;


};
