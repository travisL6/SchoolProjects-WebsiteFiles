console.log('%c I am working', 'color: green; font-weight: bold; font-size: 30px;');
console.info("hello world");

var styles = [
    'background: linear-gradient(#D33106, #571402)'
    , 'border: 1px solid #3E0E02'
    , 'color: white'
    , 'display: block'
    , 'text-shadow: 0 1px 0 rgba(0, 0, 0, 0.3)'
    , 'box-shadow: 0 1px 0 rgba(255, 255, 255, 0.4) inset, 0 5px 3px -5px rgba(0, 0, 0, 0.5), 0 -13px 5px -10px rgba(255, 255, 255, 0.4) inset'
    , 'line-height: 40px'
    , 'text-align: center'
    , 'font-weight: bold'
].join(';');

var one, two, total;
var $form;
$form = $('#form');
$('form input[type="text"]').on('blur', function() {
  if (isNaN(this.value))
  {
    console.warn('You entered ' + this.value + ' --You Must input numbers!');
    console.assert(this.value > 50, 'User entered less than 50');
  }
  else {
    console.warn('You entered ' + this.value);
  }
});

$('#form').on('submit', function(e) {
  e.preventDefault();

  one = $('#one').val();
  two = $('#two').val()
  total = Number(one) + Number(two);
  console.error(total);
  $form.append('<p class="result">' + "Answer: " + total + '</p>');

  console.group('Number calculations');
      console.info('First Number: ', one);
      console.info('Second Number: ', two);
      console.log("Total: ", total);
    console.groupEnd();
    console.log('%c Successful Entry!', styles);
    if (total < 50) {
    debugger;
  }
});

var Restaurants = {
  "Red Robin": {
    "Address": "2605 S Oneida St #100"},
  "Olive Garden": {
    "Address": "2819 S Oneida St"},
  "Hu Hot": {
    "Address": "2621 S Oneida St"}
};

console.table(Restaurants);
